# HW4P1: Autoregressive Language Modeling with Causal Transformer Decoder

## 🎯 Assignment Overview
Build a **Decoder-only Transformer** for causal language modeling from scratch, implementing both custom MyTorch components and the main transformer architecture.

**Due Date:** December 5, 2025, 11:59 PM ET
**Early Bonus:** November 21, 2025, 11:59 PM ET

---

## 📋 Core Implementation Tasks

### Task 1: MyTorch Implementations (Custom Deep Learning Library)

#### 1.1 Linear Layer (`mytorch/nn/linear.py`)
- **Forward Pass:** Y = XW^T + b (handle arbitrary batch dimensions)
- **Backward Pass:** Compute gradients for W, b, and input
- **Key:** Support broadcasting for batch dimensions (*, in_features) → (*, out_features)

#### 1.2 Softmax (`mytorch/nn/activation.py`)
- **Forward Pass:** Numerically stable softmax on specified dimension
- **Backward Pass:** Jacobian computation for gradient flow
- **Key:** Handle arbitrary dimensions, apply to specified axis

#### 1.3 Scaled Dot-Product Attention (`mytorch/nn/scaled_dot_product_attention.py`)
- **Forward Pass:**
  - Compute attention scores: QK^T / √d_k
  - Apply mask if provided
  - Apply softmax
  - Weight values: softmax(scores) * V
- **Backward Pass:** Gradients for Q, K, V through attention mechanism
- **Shape:** (N, ..., H, L, d) → (N, ..., H, L, E_v)

#### 1.4 Multi-Head Attention (`mytorch/nn/multi_head_attention.py`)
- **Forward Pass:**
  - Project Q, K, V using linear layers
  - Split into multiple heads
  - Apply scaled dot-product attention per head
  - Concatenate heads
  - Apply output projection
- **Backward Pass:** Backprop through all components
- **Helper Methods:**
  - `merge_masks()`: Combine attention and padding masks
  - `split_heads()`: Reshape for multi-head processing
  - `concat_heads()`: Merge heads back

### Task 2: Language Modeling Components

#### 2.1 Dataset Implementation (`hw4lib/data/lm_dataset.py`)
- Load text data from train/valid/test directories
- Tokenize using H4Tokenizer (provided)
- Create shifted sequences for autoregressive training:
  - Input: [SOS, token1, token2, ...]
  - Target: [token1, token2, ..., EOS]
- Implement collate function for batch padding
- Track sequence lengths for masking

#### 2.2 Masking Functions (`hw4lib/model/masks.py`)
- **CausalMask:** Create lower triangular mask for autoregression
  - Prevent attention to future tokens
  - Shape: (L, L) where L is sequence length
- **PadMask:** Create padding mask from lengths tensor
  - Mask padded positions
  - Handle variable-length sequences

#### 2.3 Positional Encoding (`hw4lib/model/positional_encoding.py`)
- Implement sinusoidal positional encoding
- Formula:
  - PE(pos, 2i) = sin(pos/10000^(2i/d_model))
  - PE(pos, 2i+1) = cos(pos/10000^(2i/d_model))
- Add positional information to embeddings

#### 2.4 Transformer Sublayers (`hw4lib/model/sublayers.py`)
- **SelfAttentionSublayer:**
  - Multi-head self-attention
  - Residual connection
  - Layer normalization
  - Dropout
- **FeedForwardSublayer:**
  - Two linear layers with ReLU
  - Residual connection
  - Layer normalization
  - Dropout

#### 2.5 Decoder Layer (`hw4lib/model/decoder_layers.py`)
- Stack self-attention and feedforward sublayers
- Apply causal masking for autoregression
- Handle padding masks

#### 2.6 Full Transformer (`hw4lib/model/transformers.py`)
- **DecoderOnlyTransformer:**
  - Token embedding layer
  - Positional encoding
  - Stack of decoder layers
  - Output projection to vocabulary

#### 2.7 Training Components (`hw4lib/trainers/lm_trainer.py`)
- Implement training loop with:
  - Forward pass through model
  - Cross-entropy loss computation
  - Backward pass and optimization
  - Perplexity tracking
- Validation loop for model evaluation
- Checkpoint saving

#### 2.8 Text Generation (`hw4lib/decoding/sequence_generator.py`)
- Implement autoregressive generation
- Support multiple sampling strategies:
  - Greedy decoding
  - Top-k sampling
  - Top-p (nucleus) sampling
  - Temperature scaling

---

## ⚙️ Implementation Guidelines

### Code Standards
1. **DO NOT remove existing comments** in starter code
2. **Minimize comments** - only add where critical
3. **Vectorize operations** wherever possible
4. **Use efficient algorithms** and good practices
5. **Complete TODOs** without modifying surrounding code structure

### Key Technical Requirements
1. **Attention Mechanism:**
   - Scale dot products by 1/√d_k for stability
   - Apply masks before softmax (use -inf for masked positions)
   - Handle batch dimensions correctly

2. **Causal Masking:**
   - Ensure no information leakage from future tokens
   - Apply consistently across all attention layers

3. **Numerical Stability:**
   - Use log-sum-exp trick for softmax
   - Careful with gradient computation through attention

4. **Memory Efficiency:**
   - Use in-place operations where safe
   - Avoid unnecessary tensor copies

---

## ✅ Acceptance Criteria

### MyTorch Components
- [ ] All MyTorch tests pass (`test_mytorch*.py`)
- [ ] Gradients match PyTorch reference implementation
- [ ] Support arbitrary batch dimensions

### Data Loading
- [ ] Dataset correctly tokenizes and creates shifted sequences
- [ ] Collate function handles variable-length sequences
- [ ] Padding masks generated correctly

### Model Components
- [ ] Causal masks prevent future token attention
- [ ] Positional encoding matches expected pattern
- [ ] All sublayer tests pass
- [ ] Decoder layer integrates components correctly

### Training & Generation
- [ ] Model trains and perplexity decreases
- [ ] Can generate coherent text sequences
- [ ] Different sampling strategies work correctly

### Testing
Run tests incrementally:
```bash
# Test MyTorch implementations
python -m pytest tests/test_mytorch*.py -v

# Test data loading
python -m pytest tests/test_dataset_lm.py -v

# Test masking
python -m pytest tests/test_mask*.py -v

# Test model components
python -m pytest tests/test_sublayer*.py -v
python -m pytest tests/test_decoderlayer*.py -v

# Test full transformer
python -m pytest tests/test_transformer_decoder_only.py -v
```

---

## 🚀 Development Workflow

1. **Start with MyTorch:** Implement and test custom components first
2. **Build Data Pipeline:** Ensure data loading and preprocessing works
3. **Implement Model Components:** Build from bottom up (masks → sublayers → decoder)
4. **Integrate & Train:** Combine all components and verify training
5. **Test Generation:** Ensure model can generate text

---

## 📝 Important Notes

1. **Self-Supervision:** Model learns by predicting next token given previous tokens
2. **Autoregressive:** Each token prediction depends only on previous tokens
3. **Decoder-Only:** No encoder; model directly processes input sequence
4. **Local Development:** Test with `hw4_data_subset/` before using full dataset

---

## 🎯 Objectives Achieved Upon Completion

- Implement self-attention from scratch
- Understand autoregressive language modeling
- Build causal masking for sequence generation
- Develop multi-head attention mechanism
- Create full transformer decoder architecture
- Train model for text generation
- Implement various decoding strategies

---

## ⚡ Performance Tips

1. **Vectorization:** Use matrix operations instead of loops
2. **Broadcasting:** Leverage NumPy/PyTorch broadcasting rules
3. **In-place Operations:** Use `+=`, `*=` where safe
4. **Batch Processing:** Process entire batches, not individual samples
5. **GPU Utilization:** Move tensors to GPU when available

---

## 🔍 Common Pitfalls to Avoid

1. **Information Leakage:** Ensure causal mask prevents seeing future
2. **Dimension Mismatches:** Carefully track tensor shapes
3. **Gradient Issues:** Check for NaN/inf in gradients
4. **Memory Leaks:** Clear intermediate tensors when not needed
5. **Indexing Errors:** Be careful with 0-indexing vs 1-indexing

---

## 📚 Key Formulas

**Scaled Dot-Product Attention:**
```
Attention(Q,K,V) = softmax(QK^T/√d_k)V
```

**Multi-Head Attention:**
```
MultiHead(Q,K,V) = Concat(head_1,...,head_h)W^O
where head_i = Attention(QW_i^Q, KW_i^K, VW_i^V)
```

**Positional Encoding:**
```
PE(pos,2i) = sin(pos/10000^(2i/d_model))
PE(pos,2i+1) = cos(pos/10000^(2i/d_model))
```

---

## 🏁 Final Checklist

- [ ] All MyTorch implementations complete and tested
- [ ] Dataset loading and preprocessing working
- [ ] All model components implemented
- [ ] Training loop functional
- [ ] Text generation working
- [ ] All tests passing
- [ ] Code follows guidelines (no removed comments, efficient implementation)